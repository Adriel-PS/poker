# Royal Texas Hold'em (Web)

Jogo de **Poker Texas Hold'em** desenvolvido em HTML5, CSS3 e JavaScript puro (sem dependências externas), com suporte para partidas **1x1** (Heads-Up) e **4x1** (Você vs 3 CPUs), três níveis de dificuldade, guia interativo de jogadas (**Passar vs Aumentar**) e interface bilíngue (**Português / English**).

## Estrutura do Projeto

- `index.html`: Estrutura da mesa, assentos, barra de status ao vivo, controles de aposta, menu inicial e modais.
- `style.css`: Estilização do feltro, responsividade e animações GPU a 60fps (virada de cartas 3D, trajetória de distribuição e fichas).
- `script.js`: Motor do jogo, avaliador completo de 7 cartas, cálculo de potes paralelos (*Side Pots*), inteligência artificial das CPUs, guia dinâmico de ações e efeitos sonoros via Web Audio API.
